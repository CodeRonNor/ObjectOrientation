public class ComputerPlayer implements Player, Strategy {

    private String name;
    private String color;
    private RandomStrategy randomStrategy;
    private RightToLeft rightToLeft;
    private PlayMiddleFirst playMiddleFirst;
    private PlayWinningMove playWinningMove;

    public ComputerPlayer(Connect4Model model) {
        this.randomStrategy = new RandomStrategy();
        this.rightToLeft = new RightToLeft();
        this.playMiddleFirst = new PlayMiddleFirst();
        this.playWinningMove = new PlayWinningMove();
        this.name = "Computer Lord";
    }


    public void play(Connect4Model model) {
        int compChoice = strategy(getColor(), model);
        while (!model.isLegalCol(compChoice)) {
            compChoice = strategy(getColor(), model);
        }
        model.putCoin(compChoice, getColor());
    }


    public String getName() {
        return name;
    }


    public Fields getColor() {
        if (this.color.equals("Red"))
            return Fields.RED;
        else
            return Fields.YELLOW;
    }

    public void setColor(Fields hpColor) {
        this.color = hpColor.other();
    }


    /**
     * Some different strategy alternatives. The current uncommented one is the most advanced so far.
     */
//    @Override
//    public int strategy(Connect4Model model) {
//        return randomStrategy.strategy(model);
//    }

//    @Override
//    public int strategy(Connect4Model model) {
//        return rightToLeft.strategy(model);
//    }

//    @Override
//    public int strategy(Connect4Model model) {
//        return playMiddleFirst.strategy(model);
//    }

    @Override
    public int strategy(Fields color, Connect4Model model) {
        return playWinningMove.strategy(this.getColor(), model);
    }
}
