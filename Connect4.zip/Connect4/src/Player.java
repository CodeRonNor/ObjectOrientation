public interface Player {

    void play(Connect4Model model);

    String getName();

    Fields getColor();
}
