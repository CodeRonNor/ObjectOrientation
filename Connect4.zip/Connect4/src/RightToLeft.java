public class RightToLeft implements Strategy {
    /**
     * This strategy is pretty dumb. He tries to fill in from right to left
     */
    @Override
    public int strategy(Fields color, Connect4Model model) {
        for (int i = 6; i >= 0; i--) {
            if (model.isLegalCol(i))
                return i;
        }
        return 0;
    }


}
