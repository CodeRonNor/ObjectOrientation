public class Connect4Controller {


    // Main menu options:
    private static final int NO_CHOICE = 0;
    private static final int PLAY_GAME = 1;
    private static final int EXIT = 2;

    Connect4Model model;
    Connect4View view;
    HumanPlayer hp;
    ComputerPlayer cp;
    Player[] players;

    public Connect4Controller() {
        this.view = new Connect4View();
        this.model = new Connect4Model();
        this.hp = new HumanPlayer();
        this.cp = new ComputerPlayer(model);
        this.players = new Player[2];
    }


    public void start() {
        int choice = NO_CHOICE;
        while (choice != EXIT) {
            view.displayMainMenu();
            choice = view.readIntWithPrompt("Enter choice: ");
            executeChoice(choice);
        }
    }

    public void executeChoice(int choice) {
        System.out.println();
        if (choice == 1) {
            hp.setName();
            hp.setColor();
            cp.setColor(hp.getColor());
            boolean userPlaysFirst = view.readYes("User plays first? (Key yes or no): ");
            playGame(userPlaysFirst);
        } else if (choice == 2) {
            view.goodbye();
        }
    }

    /**
     * Alternate between the players. Give a signal when the game is over
     */
    public void playGame(boolean firstPlayer) {
        if (firstPlayer) {
            players[0] = hp;
            players[1] = cp;

        } else {
            players[0] = cp;
            players[1] = hp;
        }
        model.getCurrentBoard();
        System.out.println();
        while (!gameOver()) {
            play();
        }
        if (model.isFull())
            view.reportFull();
        else {
            if(hp.getColor()==model.winner())
            view.reportWinner(hp);
            else
                view.reportWinner(cp);
        }
        this.model = new Connect4Model();
    }


    public void play() {

        if (!gameOver())
            players[0].play(model);
        model.getCurrentBoard();
        System.out.println();

        if (!gameOver())
            players[1].play(model);
        model.getCurrentBoard();
        System.out.println();

    }

    private boolean gameOver() {
        return (model.isFull() || model.won());
    }
}
