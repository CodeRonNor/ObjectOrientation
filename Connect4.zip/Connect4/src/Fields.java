public enum Fields {

    EMPTY, YELLOW, RED;

    @Override
    public String toString() {
        switch(this) {
            case YELLOW:
                return "O";
            case RED:
                return "X";
            default:
                return ".";
        }
    }

    public String other() {
        switch(this) {
            case YELLOW:
                return "Red";
            case RED:
                return "Yellow";
            default:
                return "Empty";
        }
    }
}
