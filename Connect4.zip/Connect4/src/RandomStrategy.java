import java.util.Random;

public class RandomStrategy implements Strategy {

    /**
     * This strategy plays randomly.
     */
    @Override
    public int strategy(Fields color, Connect4Model model) {
        Random random = new Random();
        return random.nextInt(7);
    }
}
