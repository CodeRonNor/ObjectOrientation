public class HumanPlayer implements Player {

    String name;
    String color;
    Connect4View view;


    public HumanPlayer() {
        this.view = new Connect4View();
    }


    public void play(Connect4Model model) {
        int colChoice = -1;
        while (!model.isLegalCol(colChoice)) {
            colChoice = view.getColChoice();
        }
        model.putCoin(colChoice, getColor());
    }


    public String getName() {
        return name;
    }

    public void setName() {
        this.name = view.askName();
    }


    public Fields getColor() {
        if (this.color.equals("Red"))
            return Fields.RED;
        else
            return Fields.YELLOW;
    }

    public void setColor() {
        this.color = view.askColor();
    }


}
