import java.util.Scanner;

public class Connect4View {


    Scanner scanner;


    public Connect4View() {
        this.scanner = new Scanner(System.in);
    }


    public void displayMainMenu() {
        System.out.println();
        System.out.println("Enter the number denoting the action to perform: ");
        System.out.println("Run game..............." + 1);
        System.out.println("Exit..................." + 2);
    }


    public int readIntWithPrompt(String prompt) {
        System.out.print(prompt);
        System.out.flush();
        while (!scanner.hasNextInt()) {
            scanner.nextLine();
            System.out.print(prompt);
            System.out.flush();
        }
        int input = scanner.nextInt();
        scanner.nextLine();
        return input;
    }


    public boolean readYes(String prompt) {
        String input = "";
        while (!(input.equals("yes") || input.equals("no"))) {
            System.out.print(prompt);
            System.out.flush();
            input = scanner.next();
            input = input.toLowerCase();
            scanner.nextLine();
        }
        return input.equals("yes");
    }

    public void goodbye() {
        System.out.println("Good-bye.");
    }

    public String askName() {
        System.out.println("What is your name?: ");
        return scanner.nextLine();
    }

    public String askColor() {
        String color = "";
        while (!(color.equals("R") || color.equals("Y"))) {
            System.out.println("What color would you like to play?\n"
                    + "'Y' for Yellow\n"
                    + "'R' for Red\n>>>");
            color = scanner.nextLine().toUpperCase();
        }
        if (color.equals("R")) {
            color = "Red";
        } else {
            color = "Yellow";
        }
        System.out.println("Great! You will be playing " + color + ".");
        return color;
    }

    public int getColChoice() {
        System.out.println("Where would you like to place your next coin?: ");
        return scanner.nextInt();
    }

    public void reportFull() {
        System.out.println("What a race! Can't leave it on a tie though...wanna try again?");

    }

    public void reportWinner(Player player) {
        System.out.println("winner winner chicken dinner.");
        System.out.println(player.getName() +  " wins.");
    }
}
