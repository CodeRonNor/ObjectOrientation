/**
 * @author
 *  Steffen Ricklin (s1009136)
 *  Ron Hommelsheim (s1000522)
 */

public class Connect4 {

    public static void main(String[] args) {
        new Connect4Controller().start();
    }
}
