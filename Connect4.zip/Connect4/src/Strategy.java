public interface Strategy {
    int strategy(Fields color, Connect4Model model);
}
