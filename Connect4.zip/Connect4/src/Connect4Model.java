public class Connect4Model {

    private Fields[][] board;
    private final int ROW = 6;
    private final int COL = 7;
    private boolean status;
    private Fields winner;


    public Connect4Model() {
        this.setBoard(new Fields[ROW][COL]);
        this.setBoard(initialiseBoard());
        this.status = false;
    }

    public Fields[][] initialiseBoard() {
        for (int i = 0; i < ROW; i++) {
            for (int j = 0; j < COL; j++) {
                getBoard()[i][j] = Fields.EMPTY;
            }
        }
        return getBoard();
    }


    /**
     * Checks whether the column the player wants to put the disc in is a valid move.
     */
    public boolean isLegalCol(int colChoice) {
        for (int i = ROW - 1; i >= 0; i--) {
            if (0 <= colChoice && colChoice < COL && getBoard()[i][colChoice] == Fields.EMPTY) {
                return true;
            }
        }
        return false;
    }

    public void putCoin(int coin, Fields color) {
        int row = findMinRowPos(coin);
        board[row][coin] = color;
        if (checkStatus(row, coin, color, board)) {
            this.winner = color;
            this.status = true;
        }
    }

    /**
     * This function is used for the strategy.
     */
    public boolean putCoinCopy(int coin, Fields color) {
        Fields[][] copy = copy();
        int row = findMinRowPos(coin);
        copy[row][coin] = color;
        return (checkStatus(row, coin, color, copy));
    }

    public Fields winner() {
        return winner;
    }

    /**
     * This function finds the lowest position on the boards where the disc will fall into
     */
    private int findMinRowPos(int coin) {
        for (int i = ROW - 1; i >= 0; i--) {
            if (getBoard()[i][coin] == Fields.EMPTY)
                return i;
        }
        return -1;
    }

    /**
     * Checks whether there are four in a row.
     */
    private boolean checkStatus(int row, int coin, Fields color, Fields[][] board) {
        return checkVertical(row, coin, color, board) || checkHorizontal(row, color, board) || checkDiagonalRight(row, coin, color, board)
                || checkDiagonalLeft(row, coin, color, board);
    }


    private boolean checkDiagonalRight(int row, int coin, Fields color, Fields[][] board) {
        int counter = 0;
        if (row + 3 >= ROW || coin + 3 >= COL)
            return false;
        for (int i = 0; i < 4; i++) {
            if (board[row + i][coin + i] == color) {
                counter++;
                if (counter == 4)
                    return true;
            }
        }
        return false;
    }

    private boolean checkDiagonalLeft(int row, int coin, Fields color, Fields[][] board) {
        int counter = 0;
        if (row + 3 >= ROW || coin - 3 < 0)
            return false;

        for (int i = 0; i < 4; i++) {
            if (board[row + i][coin - i] == color) {
                counter++;
                if (counter == 4)
                    return true;
            }
        }
        return false;
    }

    private boolean checkVertical(int row, int coin, Fields color, Fields[][] board) {
        if (row + 3 >= ROW)
            return false;
        if (row + 3 < ROW) {
            for (int i = 0; i < 4; i++) {
                if (board[row + i][coin] != color)
                    return false;
            }
        }
        return true;
    }

    private boolean checkHorizontal(int row, Fields color, Fields[][] board) {
        int counter;
        for (int i = 0; i < 4; i++) {
            counter = 0;
            for (int j = 0; j < 4; j++) {
                if (board[row][i + j] == color) {
                    counter++;
                    if (counter == 4)
                        return true;
                }
            }
        }
        return false;
    }


    /**
     * Makes a copy of the board.
     */
    private Fields[][] copy() {
        Fields[][] boardCopy = new Fields[6][7];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                boardCopy[i][j] = board[i][j];
            }
        }
        return boardCopy;
    }

    /**
     * Returns true if the board is full
     */
    public boolean isFull() {
        for (int i = 0; i < ROW; i++) {
            for (int j = 0; j < COL; j++) {
                if (getBoard()[i][j] == Fields.EMPTY) {
                    return false;
                }
            }
        }
        return true;
    }


    public boolean won() {
        return status;
    }


    public void getCurrentBoard() {
        for (int i = 0; i < ROW; i++) {
            for (int j = 0; j < COL; j++) {
                System.out.print(getBoard()[i][j]);
            }
            System.out.println();
        }
    }

    public Fields[][] getBoard() {
        return board;
    }

    public void setBoard(Fields[][] board) {
        this.board = board;
    }

}
