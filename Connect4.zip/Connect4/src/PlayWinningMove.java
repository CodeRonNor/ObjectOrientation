public class PlayWinningMove implements Strategy {


    /**
     * In this strategy we first copy the board in the model, next we test if any move is the last move.
     * First we exploit the situation to our advantage and else we block the opponent.
     * If there is no current best move, it uses the middle first strategy, which uses random as its alternative.
     */
    @Override
    public int strategy(Fields color, Connect4Model model) {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                if (model.isLegalCol(j)) {
                    if (color == Fields.RED) {
                        if (model.putCoinCopy(j, Fields.RED) || model.putCoinCopy(j, Fields.YELLOW))
                            return j;
                    }
                        else if (color == Fields.YELLOW)
                            if (model.putCoinCopy(j, Fields.YELLOW) || model.putCoinCopy(j, Fields.RED))
                                return j;
                }
            }
        }
        return new PlayMiddleFirst().strategy(color, model);
    }
}
