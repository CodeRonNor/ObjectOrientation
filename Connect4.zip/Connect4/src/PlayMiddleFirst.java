public class PlayMiddleFirst implements Strategy {

    RandomStrategy randomStrategy = new RandomStrategy();

    /**
     * This strategy prioritises the middle columns. Else it uses random.
     */
    @Override
    public int strategy(Fields color, Connect4Model model) {
        if (model.isLegalCol(3)) {
            return 3;
        }
        if (model.isLegalCol(2))
            return 2;
        if (model.isLegalCol(4))
            return 4;
        return randomStrategy.strategy(color, model);
    }

}
